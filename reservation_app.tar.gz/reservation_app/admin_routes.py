"""Routes for the administration interface.

The admin blueprint exposes pages to manage listings and view all
reservations.  Access to these routes is restricted to users with
administrator privileges.  If a non‑admin user attempts to access an
admin page, they are redirected to the home page.
"""

from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_required, current_user
from .extensions import db
from .models import Listing, Reservation


admin_bp = Blueprint("admin", __name__, url_prefix="/admin", template_folder="templates/admin")


def admin_required(func):
    """Decorator to ensure the current user is an administrator."""
    from functools import wraps
    @wraps(func)
    def wrapper(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin():
            flash("Accès réservé à l'administrateur.", "warning")
            return redirect(url_for("user.index"))
        return func(*args, **kwargs)
    return wrapper


@admin_bp.route("/")
@admin_required
def dashboard():
    """Display a simple dashboard with all listings and reservations."""
    listings = Listing.query.all()
    reservations = Reservation.query.order_by(Reservation.start_date.desc()).all()
    return render_template("dashboard.html", listings=listings, reservations=reservations)


@admin_bp.route("/listings/new", methods=["GET", "POST"])
@admin_required
def new_listing():
    """Create a new listing via a basic HTML form."""
    if request.method == "POST":
        title = request.form.get("title")
        description = request.form.get("description")
        price = request.form.get("price")
        if not title or not description or not price:
            flash("Tous les champs sont obligatoires.", "danger")
        else:
            try:
                price_value = float(price)
            except ValueError:
                flash("Le prix doit être un nombre.", "danger")
                return redirect(url_for("admin.new_listing"))
            listing = Listing(title=title, description=description, price=price_value, owner=current_user)
            db.session.add(listing)
            db.session.commit()
            flash("Annonce créée avec succès.", "success")
            return redirect(url_for("admin.dashboard"))
    return render_template("new_listing.html")
