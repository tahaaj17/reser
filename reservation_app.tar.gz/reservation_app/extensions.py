"""Helper module to initialize extensions for the Flask app.

This module defines singletons for SQLAlchemy and Flask‑Login. By
deferring the initialization until an application instance is created,
we avoid circular imports and can reuse the same objects across
different modules.
"""

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

# SQLAlchemy database instance.  Call ``db.init_app(app)`` in your
# application factory to attach it to the Flask app.
db = SQLAlchemy()

# Login manager instance used by Flask‑Login.  Set its ``login_view``
# attribute to the endpoint name of your login view so that
# @login_required redirects unauthenticated users.
login_manager = LoginManager()
login_manager.login_view = "user.login"