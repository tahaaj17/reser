"""Database models for the reservation application.

The application defines three core models:

* ``User`` – represents a visitor or administrator.  Includes basic
  authentication fields and a simple role flag.  In a production
  environment you should store passwords securely using hashing (e.g.
  Werkzeug ``generate_password_hash``/``check_password_hash``).

* ``Listing`` – represents an item that can be reserved, analogous to
  an Airbnb property.  Each listing has a title, description, nightly
  price and an owner (the user who created it).

* ``Reservation`` – ties a user to a listing for a specific date
  range.  For simplicity this example does not enforce availability
  constraints; in a real application you'd check for overlaps before
  creating a reservation.
"""

from datetime import date
from flask_login import UserMixin
from .extensions import db


class User(UserMixin, db.Model):
    """A registered user of the application.

    The ``role`` field distinguishes administrators from regular
    visitors.  Administrators can manage listings and see all
    reservations, while users can only create reservations and view
    their own.
    """

    __tablename__ = "users"

    id: int = db.Column(db.Integer, primary_key=True)
    email: str = db.Column(db.String(120), unique=True, nullable=False)
    password: str = db.Column(db.String(128), nullable=False)
    role: str = db.Column(db.String(20), default="user", nullable=False)

    reservations = db.relationship("Reservation", back_populates="user", cascade="all, delete-orphan")
    listings = db.relationship("Listing", back_populates="owner", cascade="all, delete-orphan")

    def is_admin(self) -> bool:
        return self.role == "admin"

    def __repr__(self) -> str:
        return f"<User id={self.id} email={self.email}>"


class Listing(db.Model):
    """An item that can be reserved.

    ``price`` is stored as a floating‑point number representing a nightly
    rate in your local currency.  In a real system you'd use a fixed
    precision type (e.g. SQLAlchemy ``Numeric``) to avoid rounding
    errors.
    """

    __tablename__ = "listings"

    id: int = db.Column(db.Integer, primary_key=True)
    title: str = db.Column(db.String(200), nullable=False)
    description: str = db.Column(db.Text, nullable=False)
    price: float = db.Column(db.Float, nullable=False)

    # Optional contact information for external booking or messaging.  If
    # ``phone_number`` is provided, the application can generate a
    # WhatsApp link so that guests can contact the host directly with
    # their reservation dates.  ``airbnb_url`` may be used to point
    # users to an existing Airbnb listing instead of handling
    # reservations internally.  Both fields are optional.
    phone_number: str = db.Column(db.String(50), nullable=True)
    airbnb_url: str = db.Column(db.String(500), nullable=True)

    owner_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    owner = db.relationship("User", back_populates="listings")

    reservations = db.relationship("Reservation", back_populates="listing", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Listing id={self.id} title={self.title}>"


class Reservation(db.Model):
    """A booking connecting a user to a listing for a set of dates."""

    __tablename__ = "reservations"

    id: int = db.Column(db.Integer, primary_key=True)
    start_date: date = db.Column(db.Date, nullable=False)
    end_date: date = db.Column(db.Date, nullable=False)

    user_id: int = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    user = db.relationship("User", back_populates="reservations")

    listing_id: int = db.Column(db.Integer, db.ForeignKey("listings.id"), nullable=False)
    listing = db.relationship("Listing", back_populates="reservations")

    status: str = db.Column(db.String(20), default="pending", nullable=False)

    def __repr__(self) -> str:
        return f"<Reservation id={self.id} user={self.user.email} listing={self.listing.title}>"