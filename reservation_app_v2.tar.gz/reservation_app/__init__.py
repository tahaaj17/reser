"""Top‑level package for the reservation application.

This file marks ``reservation_app`` as a Python package so that
relative imports work correctly when running under WSGI servers such
as Gunicorn.  It does not need to contain any code.
"""

__all__ = []