"""Routes for regular users (guests).

This blueprint handles the public‑facing part of the site: browsing
listings, viewing details, logging in/out and making reservations.
"""

from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required, current_user
from .extensions import db, login_manager
from .models import User, Listing, Reservation


user_bp = Blueprint("user", __name__, template_folder="templates/user")


@user_bp.route("/")
def index():
    """Home page showing all available listings."""
    listings = Listing.query.all()
    return render_template("index.html", listings=listings)


@user_bp.route("/listing/<int:listing_id>", methods=["GET", "POST"])
def listing_detail(listing_id):
    """Show a single listing and handle reservation submission."""
    listing = Listing.query.get_or_404(listing_id)
    if request.method == "POST":
        # Require authentication to proceed
        if not current_user.is_authenticated:
            flash("Veuillez vous connecter pour réserver.", "warning")
            return redirect(url_for("user.login"))
        start_str = request.form.get("start_date")
        end_str = request.form.get("end_date")
        try:
            start_date = datetime.strptime(start_str, "%Y-%m-%d").date()
            end_date = datetime.strptime(end_str, "%Y-%m-%d").date()
            if end_date < start_date:
                raise ValueError
        except Exception:
            flash("Veuillez saisir des dates valides.", "danger")
            return redirect(url_for("user.listing_detail", listing_id=listing_id))
        # If a phone number is defined, redirect to WhatsApp with a pre‑filled message
        if listing.phone_number:
            import urllib.parse as urlparse
            message = f"Bonjour, je souhaite réserver {listing.title} du {start_date.strftime('%d/%m/%Y')} au {end_date.strftime('%d/%m/%Y')}"
            encoded_message = urlparse.quote(message)
            # Remove non‑digit characters from phone number just in case
            phone_digits = ''.join(ch for ch in listing.phone_number if ch.isdigit())
            wa_url = f"https://wa.me/{phone_digits}?text={encoded_message}"
            return redirect(wa_url)
        # Otherwise, if an Airbnb URL is provided, redirect there
        if listing.airbnb_url:
            return redirect(listing.airbnb_url)
        # Fallback: record reservation internally
        reservation = Reservation(user=current_user, listing=listing, start_date=start_date, end_date=end_date)
        db.session.add(reservation)
        db.session.commit()
        flash("Réservation enregistrée. Elle est en attente de confirmation.", "success")
        return redirect(url_for("user.profile"))
    return render_template("listing_detail.html", listing=listing)


@user_bp.route("/profile")
@login_required
def profile():
    """Display current user's reservations."""
    reservations = current_user.reservations
    return render_template("profile.html", reservations=reservations)


@user_bp.route("/login", methods=["GET", "POST"])
def login():
    """Handle user authentication with a simple form."""
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        user = User.query.filter_by(email=email).first()
        if user and user.password == password:
            login_user(user)
            flash("Connexion réussie.", "success")
            next_page = request.args.get("next")
            return redirect(next_page or url_for("user.index"))
        flash("Identifiants invalides.", "danger")
    return render_template("login.html")


@user_bp.route("/logout")
@login_required
def logout():
    """Log out the current user."""
    logout_user()
    flash("Vous êtes déconnecté.", "info")
    return redirect(url_for("user.index"))


@login_manager.user_loader
def load_user(user_id: str):
    return User.query.get(int(user_id))