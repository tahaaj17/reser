"""Application factory and entry point for the reservation site.

The ``create_app`` function constructs and configures the Flask
application.  It registers blueprints, initializes extensions and
makes sure the database tables exist.  The global ``app`` object is
created for convenience when running with Gunicorn (see Procfile or
Render start command).
"""

from flask import Flask
from .extensions import db, login_manager
from .admin_routes import admin_bp
from .user_routes import user_bp


def create_app() -> Flask:
    app = Flask(__name__)
    # Basic configuration.  In production you should load these from
    # environment variables or configuration files.
    app.config["SECRET_KEY"] = "change-me-to-a-secure-random-string"
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///app.db"
    app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)

    # Register blueprints
    app.register_blueprint(user_bp)
    app.register_blueprint(admin_bp)

    # Create tables on first run
    with app.app_context():
        db.create_all()

    return app


# WSGI entry point for Gunicorn.  See Render start command.
app = create_app()


if __name__ == "__main__":
    # Run the development server.  This block is not used in production.
    app.run(debug=True)